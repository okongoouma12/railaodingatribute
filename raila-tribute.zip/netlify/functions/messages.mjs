import { getStore } from "@netlify/blobs";
import { handle } from "../lib/handle.mjs";

export default async (req, context) =>
  handle({
    req,
    ip: context.ip,
    messages: getStore({ name: "messages", consistency: "strong" }),
    limits: getStore({ name: "ratelimit", consistency: "strong" }),
    adminKey: Netlify.env.get("ADMIN_KEY"),
  });

export const config = { path: "/api/messages" };
